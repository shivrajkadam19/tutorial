<?php

// $url = 'https://quizz.soft2technologies.com';

$url = 'http://localhost/tutorial/admin/api';


$server = "localhost";
$username = "root";
$dbname = "quizapp2";
$password = "";